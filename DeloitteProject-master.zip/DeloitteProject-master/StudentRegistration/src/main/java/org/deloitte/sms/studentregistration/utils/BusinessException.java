package org.deloitte.sms.studentregistration.utils;


public class BusinessException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BusinessException(String s) {
		super(s);
	}
}
